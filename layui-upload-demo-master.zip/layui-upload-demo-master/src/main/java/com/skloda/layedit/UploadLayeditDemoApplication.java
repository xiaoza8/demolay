package com.skloda.layedit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadLayeditDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(UploadLayeditDemoApplication.class, args);
    }

}
