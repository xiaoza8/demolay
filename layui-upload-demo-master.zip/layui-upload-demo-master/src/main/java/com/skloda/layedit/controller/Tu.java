package com.skloda.layedit.controller;

public class Tu {

   public  String  password;
    public  String  title;
    public  String  sex;
    public  String  city;
    public  String  urlStringList;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getUrlStringList() {
        return urlStringList;
    }

    public void setUrlStringList(String urlStringList) {
        this.urlStringList = urlStringList;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public  String  desc;

}
