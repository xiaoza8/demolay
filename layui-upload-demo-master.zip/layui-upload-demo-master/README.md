# LayUI上传组件示例
> upload组件多文件上传demo

> layedit富文本编辑器的图片上传demo